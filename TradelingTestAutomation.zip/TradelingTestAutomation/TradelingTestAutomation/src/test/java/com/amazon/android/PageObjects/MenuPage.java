package com.amazon.android.PageObjects;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.amazon.apps.Locators.AndroidLocators;
import com.amazon.apps.utils.AndroidUtils;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



public class MenuPage {
	
	AndroidUtils utils;
	
	@FindBy(id=AndroidLocators.SkipSIGN_ID)
	MobileElement SkipSIGN_ID ;

	@FindBy(xpath=AndroidLocators.MenuButton_XPath)
	WebElement MenuButton_ID ;
	
	@FindBy(id=AndroidLocators.ButtSettingson_ID)
	MobileElement ButtSettingson_ID ;
	
	@FindBy(xpath=AndroidLocators.ButtSettingson1_XPath)
	WebElement ButtSettingson1 ;
	
	@FindBy(xpath=AndroidLocators.CountryChangeButton_XPath)
	MobileElement CountryChangeButton_XPath ;
	
	@FindBy(xpath=AndroidLocators.CountryChangeButton1_XPath)
	WebElement CountryChangeButton1_XPath ;
	
	@FindBy(xpath=AndroidLocators.	CountryChangeUSTOUAEButton_XPath)
	WebElement 	CountryChangeUSTOUAEButton_XPath ;
	
	@FindBy(xpath=AndroidLocators.CountrySelectionButton_XPath)
	MobileElement CountrySelectionButton_XPath ;
	
	@FindBy(xpath=AndroidLocators.	CountrySelectionButton1_XPath)
	MobileElement 	CountrySelectionButton1_XPath ;
	
	@FindBy(xpath=AndroidLocators.Done_XPath)
	WebElement Done_XPath ;
	
	@FindBy(xpath=AndroidLocators.YourAccount_XPath)
	WebElement YourAccount_XPath ;
	
	@FindBy(xpath=AndroidLocators.YourPayment_XPath)
	WebElement YourPayment_XPath ;
	
	@FindBy(xpath=AndroidLocators.PaymentType_XPath)
	WebElement PaymentType_XPath ;
	
	@FindBy(xpath=AndroidLocators.ManageGiftCardBalance_XPath)
	WebElement ManageGiftCardBalance_XPath ;
	
	@FindBy(xpath=AndroidLocators.ZeroGiftCardBalance_XPath)
	WebElement ZeroGiftCardBalance ;
	
	@FindBy(xpath=AndroidLocators.ShopByDept_XPath)
	WebElement ShopByDept ;
	
	@FindBy(xpath=AndroidLocators.Electronics_XPath)
	WebElement Electronics ;
	
	@FindBy(xpath=AndroidLocators.TvVideo_XPath)
	WebElement TvVideo ;
	
	@FindBy(xpath=AndroidLocators.ManageYourAddress_XPath)
	WebElement ManageYourAddress ;

	@FindBy(xpath=AndroidLocators.AddNewAddress_XPath)
	WebElement AddNewAddress_XPath ;
	
	@FindBy(xpath=AndroidLocators.StreetAddress_XPath)
	WebElement StreetAddress_XPath ;
	
	@FindBy(xpath=AndroidLocators.CityAddress_XPath)
	WebElement 	CityAddress_XPath ;
	
	@FindBy(xpath=AndroidLocators.ZipCodeAddress_XPath)
	WebElement 	ZipCodeAddress_XPath ;
	
	@FindBy(xpath=AndroidLocators.StateAddress_XPath)
	WebElement 	StateAddress_XPath ;
	
	@FindBy(xpath=AndroidLocators.StateSelection_XPath)
	WebElement 	StateSelection_XPath ;
	
	@FindBy(xpath=AndroidLocators.AddAddress_XPath)
	WebElement AddAddress_XPath ;
	

	@FindBy(xpath=AndroidLocators.Addressverification_XPath)
	WebElement 	Addressverification_XPath ;
	
	AppiumDriver<MobileElement> driver;
	private static Logger testLogger = LogManager.getLogger(Logger.class.getName());
	
	public MenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	/*-------------> The code below belongs to Test Methods<---------------------  */	

	public boolean navigateToMenuPage(){
		boolean flag=true;
		try{
			
			WebDriverWait wait1 = new WebDriverWait(driver,50);
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.ImageView[@content-desc='Navigation panel, button, double tap to open side panel']")));					
			if(MenuButton_ID.isDisplayed()==true){
				testLogger.info("Fetching SignIn: "+MenuButton_ID.getText());
				MenuButton_ID.click();
				System.out.println("Clicking to Menu button");
				testLogger.info("Fetching SignIn: "+ButtSettingson_ID.getText());
				ButtSettingson_ID.click();
				testLogger.info("Fetching ConfirmEmail: "+CountryChangeButton_XPath.getText());
				CountryChangeButton_XPath.click();
				testLogger.info("Fetching Country Name: "+CountryChangeButton1_XPath.getText());
				CountryChangeButton1_XPath.click();
				CountrySelectionButton_XPath.click();
				Done_XPath.click();
		}
		}catch(Exception exp)
		{
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	
	public boolean navigateToCurrencyChange(){
		boolean flag=true;
		try{
			SkipSIGN_ID.click();
			navigateToMenuPage();					
			if(MenuButton_ID.isDisplayed()==true){
				testLogger.info("Fetching SignIn: "+MenuButton_ID.getText());
				MenuButton_ID.click();
				System.out.println("Clicking to Menu button");
				testLogger.info("Fetching SignIn: "+ButtSettingson1.getText());
				ButtSettingson1.click();
				testLogger.info("Fetching ConfirmEmail: "+CountryChangeButton_XPath.getText());
				CountryChangeButton_XPath.click();
				testLogger.info("Fetching Country Name: "+CountryChangeUSTOUAEButton_XPath.getText());
				CountryChangeUSTOUAEButton_XPath.click();
				CountrySelectionButton1_XPath.click();
				Done_XPath.click();	
		}
		}catch(Exception exp)
		{
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	
	public boolean skipSignIn(){
		boolean flag=true;
		try{
			SkipSIGN_ID.click();					

		}catch(Exception exp)
		{
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	
	
	public boolean navigateToYouAccount(){
		boolean flag=true;
		try{
			if(MenuButton_ID.isDisplayed()==true){
				testLogger.info("Fetching SignIn: "+MenuButton_ID.getText());
				MenuButton_ID.click();
				testLogger.info("Fetching SignIn: "+YourAccount_XPath.getText());
				YourAccount_XPath.click();
				for(int i=0;i<=1;i++) 
				 {
					AndroidUtils swipeElement = new AndroidUtils(driver);
					swipeElement.swipeUp();
				 }
	 		    testLogger.info("Fetching Your payment: "+YourPayment_XPath.getText());
	 		    YourPayment_XPath.click();
	 		    testLogger.info("Fetching Payment type: "+PaymentType_XPath.getText());
	 		    driver.navigate().back();
		}
		}catch(Exception exp)
		{
			
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	
	public boolean navigateToManageGiftCardBlnce(){
		boolean flag=true;
		try{
			
			if(MenuButton_ID.isDisplayed()==true){
				MenuButton_ID.click();
				YourAccount_XPath.click();	
				for(int i=0;i<=2;i++) 
				 {
					AndroidUtils swipeElement = new AndroidUtils(driver);
					swipeElement.swipeUp();
				 }
			}
	
			if(ManageGiftCardBalance_XPath.isDisplayed()==true){
				testLogger.info("Fetching Manage Gift card: "+ManageGiftCardBalance_XPath.getText());
				ManageGiftCardBalance_XPath.click();
				testLogger.info("Fetching Gift card balance: "+ZeroGiftCardBalance.getText());

			}
		}catch(Exception exp)
		{
			//testLogger.error("Unable to choose the product listed as search result",exp);
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	
	public boolean navigateToShopByDepartment(){
		boolean flag=true;
		try{
			SkipSIGN_ID.click();
			navigateToMenuPage();
			if(MenuButton_ID.isDisplayed()==true){
				testLogger.info("Fetching Menu: "+MenuButton_ID.getText());	
				MenuButton_ID.click();
			}
			
			if(ShopByDept.isDisplayed()==true){
				ShopByDept.click();
				for(int i=0;i<=1;i++) 
				 {
					AndroidUtils swipeElement = new AndroidUtils(driver);
					swipeElement.swipeUp();
				 }
			}
	
			if(Electronics.isDisplayed()==true){
				testLogger.info("Fetching Electronics: "+Electronics.getText());
				Electronics.click();
				System.out.println("Clicking to Electronics sub department");
				WebDriverWait wait1 = new WebDriverWait(driver,50);
				wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.Image[@text='TV & Video']")));
				TvVideo.click();

			}
		}catch(Exception exp)
		{
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	
	public boolean navigateToManageAddressBook(){
		boolean flag=true;
		try{
			
			if(MenuButton_ID.isDisplayed()==true){
				MenuButton_ID.click();
				YourAccount_XPath.click();	
				for(int i=0;i<=0;i++) 
				 {
					AndroidUtils swipeElement = new AndroidUtils(driver);
					swipeElement.swipeUp();
				 }
			}
	
			if(ManageYourAddress.isDisplayed()==true){
				testLogger.info("Fetching Menu-Addresses: "+ManageYourAddress.getText());
				ManageYourAddress.click();
				AddNewAddress_XPath.click();
				StreetAddress_XPath.click();
				StreetAddress_XPath.sendKeys("Test General Delivery");
				driver.navigate().back();
				CityAddress_XPath.click();
				CityAddress_XPath.sendKeys("Clayton");
				driver.navigate().back();
				ZipCodeAddress_XPath.click();
				ZipCodeAddress_XPath.sendKeys("99110");
				driver.navigate().back();
				StateAddress_XPath.click();
				StateSelection_XPath.click();
				for(int i=0;i<=0;i++) {
					AndroidUtils swipeElement = new AndroidUtils(driver);
					swipeElement.swipeUp();}	
				AddAddress_XPath.click();	
				String ActualTitle = Addressverification_XPath.getText();
				String ExpectedTitle = "TEST GENERAL DELIVERY";
			    assertEquals(ActualTitle, ExpectedTitle);
			    System.out.println("Actual is equal to expected");
			}
		}catch(Exception exp)
		{
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	
	
}
