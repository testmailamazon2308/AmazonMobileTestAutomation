package com.amazon.android.PageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.amazon.android.PageObjects.MenuPage;
import com.amazon.apps.Locators.AndroidLocators;
import com.amazon.apps.utils.AndroidUtils;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class PDP {
	
	AndroidUtils utils;
	
	
	@FindBy(id=AndroidLocators.PDP_image_ID)
	WebElement PDP_image ;
	
	
	@FindBy(xpath=AndroidLocators.SLP_SearchSujjestion_XPath)
	WebElement SLP_SearchSujjestion; 
	
	@FindBy(id=AndroidLocators.HP_SearchSujjestion_ID)
	WebElement HP_SearchSujjestion;
	
	
	@FindBy(xpath=AndroidLocators.PDP_ProductPrice_XPath)
	WebElement PDP_ProductPrice_XPath;
	
	
	@FindBy(xpath=AndroidLocators.PDPStock_XPath)
	WebElement PDPStock_XPath ;
	
	@FindBy(xpath=AndroidLocators.PDP_AddToCart_XPath)
	WebElement PDP_AddToCart_XPath; 
	
	
	AppiumDriver<MobileElement> driver;
	private static Logger testLogger = LogManager.getLogger(Logger.class.getName());
	
	
	public PDP(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	/*-------------> The code below belongs to Test Methods<---------------------  */	

	public boolean navigateToPDP(){
		boolean flag=true;
		try{
			WebDriverWait wait1 = new WebDriverWait(driver,50);
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='AED 1,430.00']")));					
				
			if(SLP_SearchSujjestion.isDisplayed()==true){
				SLP_SearchSujjestion.click();
				for(int i=0;i<=1;i++) 
				 {
					AndroidUtils swipeElement = new AndroidUtils(driver);
					swipeElement.swipeUp();
				 }
				testLogger.info("Fetching SignIn: "+PDP_ProductPrice_XPath.getText());
				testLogger.info("Fetching SignIn: "+PDPStock_XPath.getText());
				for(int i=0;i<=0;i++) 
				 {
					AndroidUtils swipeElement = new AndroidUtils(driver);
					swipeElement.swipeUp();
				 }
				if(PDP_AddToCart_XPath.isDisplayed()==true){
				PDP_AddToCart_XPath.click();	
				}
		}
		}catch(Exception exp)
		{
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	

	
	
}
