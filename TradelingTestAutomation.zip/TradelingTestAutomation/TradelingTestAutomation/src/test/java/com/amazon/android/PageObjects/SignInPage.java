package com.amazon.android.PageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.amazon.apps.Locators.AndroidLocators;
import com.amazon.apps.utils.AndroidUtils;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



public class SignInPage {
	
	AndroidUtils utils;
	

	@FindBy(id=AndroidLocators.SIGN_ID)
	MobileElement SIGN_ID ;
	
	@FindBy(xpath=AndroidLocators.SignInEmail_XPath)
	WebElement SignInEmail_ID ;
	
	@FindBy(xpath=AndroidLocators.ConfirmEmail_XPath)
	WebElement ConfirmEmail_ID;
	
	@FindBy(xpath=AndroidLocators.SignInPassword_XPath)
	WebElement SignInPassword_XPath ;
	
	@FindBy(xpath=AndroidLocators.SignInButton_XPath)
	MobileElement SignInButton_XPath;
	
	
	

	


	AppiumDriver<MobileElement> driver;
	private static Logger testLogger = LogManager.getLogger(Logger.class.getName());
	
	
	public SignInPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	/*-------------> The code below belongs to Test Methods<---------------------  */	

	public boolean navigateToSignInPage(){
		boolean flag=true;
		try{
					
			if(SIGN_ID.isDisplayed()==true){
				testLogger.info("Fetching SignIn: "+SIGN_ID.getText());
				
				SIGN_ID.click();
				//AndroidUtils swipeElement = new AndroidUtils(driver);
	 		    //swipeElement.allowAppPermission();
				System.out.println("Clicking to SignIn button");
				
				WebDriverWait wait = new WebDriverWait(driver,50);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.EditText[contains(@resource-id,'ap_email_login') and @index='1']")));
				testLogger.info("Fetching SignIn: "+SignInEmail_ID.getText());
				SignInEmail_ID.click();
				SignInEmail_ID.sendKeys("testmaileve@gmail.com");
				driver.navigate().back();
				
//				WebDriverWait wait1 = new WebDriverWait(driver,50);
//				wait1.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.amazon.mShop.android.shopping:id/continue")));
				testLogger.info("Fetching ConfirmEmail: "+ConfirmEmail_ID.getText());
				ConfirmEmail_ID.click();
				SignInPassword_XPath.click();
				SignInPassword_XPath.sendKeys("test@1234");
				SignInButton_XPath.click();
				
		}
		}catch(Exception exp)
		{
			//testLogger.error("Unable to choose the product listed as search result",exp);
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	

	
	
}
