package com.amazon.apps.utils;

import java.time.Duration;
import java.util.HashMap;
import java.util.Set;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amazon.apps.Locators.AndroidLocators;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

//import com.swan.android.PageObjects.DeviceLocation_PermissionDeny_ID;

public class AndroidUtils {
	
//	@FindBy(id = AndroidLocators.DeviceLocation_PermissionAllow_ID)
//	WebElement DeviceLocation_PermissionAllow;
//	
	static AppiumDriver<MobileElement> driver;
	private static Logger testLogger = LogManager.getLogger(Logger.class.getName());

	public AndroidUtils(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	/*-------------> The code below belongs to Test Methods<---------------------  */	
	
	public void Wait(int Seconds) {
		int miliseconds;
		try {
			miliseconds = Seconds * 1000;
			Thread.sleep(miliseconds);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException Ex) {
			return false;
		}
	}
	
//	public void allowAppPermission() {
//		 while
//		(testdriver.findElements(MobileBy.xpath(AndroidLocators.myAccountNewAddressDeviceLocation_PermissionDeny_Xpath)).size()
//		> 0)
//		 {
//		 testdriver.findElement(MobileBy.xpath(AndroidLocators.myAccountNewAddressDeviceLocation_PermissionDeny_Xpath)).click();
//		 }
//		
//		
//		//DeviceLocation_PermissionAllow.click();
//		driver.findElement(MobileBy.id(AndroidLocators.DeviceLocation_PermissionAllow_ID)).click();
//
//	}
	
	public void scroll(String down) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("direction", down);
		js.executeScript("mobile: scroll", scrollObject);

	}

	public void scrollUp(String up) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("direction", up);
		js.executeScript("mobile: scroll", scrollObject);

	}

	public void scrollleft(String left) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("direction", left);
		js.executeScript("mobile: scroll", scrollObject);

	}

	public void scrollright(String right) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("direction", right);
		js.executeScript("mobile: scroll", scrollObject);

	}
	
	public void swipeUp() {
		Set<String> availableContexts = driver.getContextHandles();
		for (String context : availableContexts)
			if (context.contains("NATIVE_APP")) {
				Dimension size = driver.manage().window().getSize();
				int starty = (int) (size.height * 0.100);
				int endy = (int) (size.height * 0.60);
				int center = size.width / 2;
				TouchAction actions = new TouchAction(driver);
				actions.press(PointOption.point(center, endy))
						.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
						.moveTo(PointOption.point(center, starty)).release().perform();

			} else {
				testLogger.error("Unable to perform swipe down operation");
			}

	}

	public void swipeDown() {
		Set<String> availableContexts = driver.getContextHandles();
		for (String context : availableContexts)
			if (context.contains("NATIVE_APP")) {
				Dimension size = driver.manage().window().getSize();
				int starty = (int) (size.height/2);
				int endy = (int) (size.height-100);
				int center = size.width / 2;
				TouchAction actions = new TouchAction(driver);
				actions.press(PointOption.point(center, starty))
						.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
						.moveTo(PointOption.point(center, endy)).release().perform();

			} else {
				testLogger.error("Unable to perform swipe up operation");
			}

	}
	


	

}
