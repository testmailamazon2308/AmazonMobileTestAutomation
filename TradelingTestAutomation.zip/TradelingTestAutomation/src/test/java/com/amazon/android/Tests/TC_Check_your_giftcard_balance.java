package com.amazon.android.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.amazon.android.PageObjects.MenuPage;
import com.amazon.android.PageObjects.SignInPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TC_Check_your_giftcard_balance extends BaseClass {
	
	SignInPage confirm;
	MenuPage menu;

	
	@Test(alwaysRun=true, priority=1)
	public void TC_SignInToAmazon(ITestContext context){
	
		System.out.println("Test Started TC_NavigateTo_SignInPage");
		context.setAttribute("description","Confirm SignIn page");
		SignInPage accessTestMethod = new SignInPage(driver); 
		Assert.assertTrue(accessTestMethod.navigateToSignInPage());
		System.out.println("Completed Test TC_NavigateTo_SignInPage");
	}
	
	@Test(alwaysRun=true, priority=2)
	public void TC_Verify_GiftCardBalance_$0(ITestContext context){
	
		System.out.println("Test Started TC_Verify_GiftCardBalance_$0.00");
		context.setAttribute("description","Confirm gift card balance is:  $0.00");
		MenuPage accessTestMethod = new MenuPage(driver); 
		Assert.assertTrue(accessTestMethod.navigateToMenuPage());
		MenuPage accessTestMethodd = new MenuPage(driver); 
		Assert.assertTrue(accessTestMethodd.navigateToManageGiftCardBlnce());
		System.out.println("Completed Test TC_Verify_GiftCardBalance_$0.00");
	}
}
